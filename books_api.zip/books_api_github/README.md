# Books API (Flask)

A simple REST API for retrieving books and adding new books. The API has two endpoints and an OpenAPI 3.0 specification.

## Requirements

- Python 3.9 or newer
- pip

## Setup and run

1. Clone or download this repository.
2. Open a terminal in the project folder.
3. (Recommended) Create and activate a virtual environment:

   **Windows**
   ```bash
   python -m venv venv
   venv\\Scripts\\activate
   ```

   **macOS/Linux**
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   ```

4. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

5. Start the Flask server:

   ```bash
   python app.py
   ```

The API runs locally at `http://127.0.0.1:5000`.

## Endpoints

### GET `/books`

Returns all books.

Example response:

```json
[
  {
    "id": 1,
    "title": "Python Basics",
    "author": "John"
  },
  {
    "id": 2,
    "title": "Web Development",
    "author": "Smith"
  }
]
```

### POST `/books`

Adds a book. Send a JSON body with both `title` and `author`.

Example request:

```json
{
  "title": "Flask Guide",
  "author": "Alex"
}
```

Successful response: HTTP `201 Created`.

If `title` or `author` is missing, the API returns HTTP `400 Bad Request` with:

```json
{
  "error": "Title and author are required"
}
```

## Test with curl

Get books:

```bash
curl http://127.0.0.1:5000/books
```

Add a book:

```bash
curl -X POST http://127.0.0.1:5000/books -H "Content-Type: application/json" -d "{\"title\":\"Flask Guide\",\"author\":\"Alex\"}"
```

## API documentation

`openapi.yaml` contains the OpenAPI 3.0 specification. You can paste it into [Swagger Editor](https://editor.swagger.io/) to view the API documentation and try the endpoints after the Flask app is running.

## Note

Books are stored in an in-memory Python list, so newly added books are lost when the server restarts. This is intended as a simple practical/lab example.
